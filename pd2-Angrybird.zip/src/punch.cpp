#include "punch.h"
#include <QDebug>
#include <math.h>


extern QString *BIRD;
extern QString *LAND;
extern QString *PIG;
extern QString *BAR;

void Punch::BeginContact(b2Contact *contact)
{

    if(contact->GetFixtureA()->GetBody()->GetUserData() == BAR && contact->GetFixtureB()->GetBody()->GetUserData() == BIRD){ //|| (contact->GetFixtureA()->GetBody()->GetUserData() == BIRD && contact->GetFixtureB()->GetBody()->GetUserData() == BLOCK)){
        iscontacted = 1;
        qDebug()<<"iscontact is 1";
    }



    if(contact->GetFixtureA()->GetBody()->GetUserData() == BIRD && contact->GetFixtureB()->GetBody()->GetUserData() == PIG){
        iscontacted = 1;
        //qDebug()<<"iscontact is 1";
    }
    if(contact->GetFixtureA()->GetBody()->GetUserData() == PIG && contact->GetFixtureB()->GetBody()->GetUserData() == BIRD){
        iscontacted = 1;
        //qDebug()<<"iscontact is 1";
    }
}

void Punch::PreSolve(b2Contact *contact, const b2Manifold *oldManifold)
{
    /*
    if(contact->GetFixtureB()->GetBody()->GetUserData() == BIRD && contact->GetFixtureA()->GetBody()->GetUserData() == BUN)
        contact->SetEnabled(false);
    if(contact->GetFixtureB()->GetBody()->GetUserData() == BIRD && contact->GetFixtureA()->GetBody()->GetUserData() == ROPE)
        contact->SetEnabled(false);
        */
}

void Punch::PostSolve(b2Contact *contact, const b2ContactImpulse *impulse)
{

}

void Punch::EndContact(b2Contact *contact)
{
    ;
}
