#ifndef MYCALLBACK_H
#define MYCALLBACK_H
#include <Box2D/Box2D.h>

class MyCallBack : public b2QueryCallback
{
public:
    MyCallBack();

};

#endif // MYCALLBACK_H
