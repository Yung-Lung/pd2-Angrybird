#ifndef PUNCH_H
#define PUNCH_H


#include <Box2D/Box2D.h>
class Punch : public b2ContactListener{
public:
    void BeginContact(b2Contact *contact);
    void PreSolve(b2Contact *contact, const b2Manifold *oldManifold);
    void PostSolve(b2Contact *contact, const b2ContactImpulse *impulse);
    void EndContact(b2Contact *contact);

private:
    bool iscontacted = 0;
};

#endif // PUNCH_H
