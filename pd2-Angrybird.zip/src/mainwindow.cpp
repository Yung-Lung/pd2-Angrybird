#include "mainwindow.h"
#include "ui_mainwindow.h"

double rx_o = 5.0,ry_o = 8.0;
double mx,my;
int BIRD_INDEX=1;
int BIRD_INDEX_move=1;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Enable the event Filter
    qApp->installEventFilter(this);
    setMouseTracking(true);
    ui->label->setPixmap(QPixmap(":/image/egg.png").scaled(ui->label->size()));
    ui->label->setVisible(1);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showEvent(QShowEvent *)
{
    // Setting the QGraphicsScene
    scene = new QGraphicsScene(0,0,width(),ui->graphicsView->height());
    scene->addPixmap(QPixmap(":/image/Forever.jpg").scaled(this->size()));
    ui->graphicsView->setScene(scene);
    // Create world
    world = new b2World(b2Vec2(0.0f, -9.8f));
    // Setting Size
    GameItem::setGlobalSize(QSizeF(32,18),size());
    // Create ground (You can edit here)
    ground = new Land(16,1.5,32,3,QPixmap(":/ground.png").scaled(width(),height()/6.0),world,scene);
    // Create bird (You can edit here)
    birdie = new Bird(5.0f,10.0f,0.27f,&timer,QPixmap(":/green_bird").scaled(height()/9.0,height()/9.0),world,scene);
    black = new Bird(-5.0f,10.0f,0.27f,&timer,QPixmap(":/black_bird").scaled(height()/9.0,height()/9.0),world,scene);
    white = new Bird(-10.0f,10.0f,0.27f,&timer,QPixmap(":/white_bird").scaled(height()/9.0,height()/9.0),world,scene);
    blue = new Bird(-15.0f,10.0f,0.27f,&timer,QPixmap(":/blue_bird").scaled(height()/9.0,height()/9.0),world,scene);
    // Setting the Velocity
    //use it for mouse release
    //birdie->setLinearVelocity(b2Vec2(5,5));
    //itemList.push_back(birdie);

    bar1 = new Bar(15.0f,5.0f,1.0f,&timer,QPixmap(":/pica").scaled(height()/8.0,height()/5.0),world,scene);
    bar2 = new Bar(25.0f,5.0f,0.27f,&timer,QPixmap(":/bar").scaled(height()/9.0,height()/9.0),world,scene);

    enemy = new Pig(20.0f,5.0f,0.27f,&timer,QPixmap(":/pig_1").scaled(height()/9.0,height()/9.0),world,scene);
    // Timer
    connect(&timer,SIGNAL(timeout()),this,SLOT(tick()));
    connect(this,SIGNAL(quitGame()),this,SLOT(QUITSLOT()));
    timer.start(100/6);
}
    int check=0;
    double mx_a;
    double my_a;
bool MainWindow::eventFilter(QObject *, QEvent *event)
{
    mx_a = static_cast<QMouseEvent*>(event)->x()/30 - mx;
    my_a = (17 - static_cast<QMouseEvent*>(event)->y()/30) -my;
    // Hint: Notice the Number of every event!
    if(event->type() == QEvent::MouseButtonPress)
    {
        mx = static_cast<QMouseEvent*>(event)->x()/30;
        my = 17 - static_cast<QMouseEvent*>(event)->y()/30;
        switch(BIRD_INDEX){
            case 1:
                birdie->test(rx_o,rx_o);
                break;
            case 6:
                black->test(rx_o,rx_o);
                break;
            case 11:
                break;
            case 16:
                break;
        }
                        BIRD_INDEX++;
        //birdie->test(rx_o,rx_o);
        check=1;
        //birdie->setLinearVelocity(b2Vec2(2.5f,2.5f));
        /* TODO : add your code here */
       // std::cout << "Press !" << kk << std::endl;
    }
    if(event->type() == QEvent::MouseMove)
    {

        if(check==1){
            switch(BIRD_INDEX_move){
                case 1:
                    birdie->test((rx_o+mx_a),(ry_o+my_a));
                    birdie->getself().SetGravityScale(0.0f);
                    break;
                case 3:
                    black->test((rx_o+mx_a),(ry_o+my_a));
                    black->getself().SetGravityScale(0.0f);
                    break;
                case 5:
                    white->test((rx_o+mx_a),(ry_o+my_a));
                    white->getself().SetGravityScale(0.0f);
                    break;
                case 7:
                    blue->test((rx_o+mx_a),(ry_o+my_a));
                    blue->getself().SetGravityScale(0.0f);
                    break;
            }
        }
        /* TODO : add your code here */
        //std::cout << "Move !" << std::endl ;

        std::cout << my_a<< std::endl;
        std::cout << mx_a<< std::endl;
        std::cout<<"index:"<<BIRD_INDEX<<std::endl;
    }

    if(event->type() == QEvent::MouseButtonRelease)
    {
        check=0;

        switch(BIRD_INDEX){
            case 6:
                birdie->getself().SetGravityScale(0.98f);
                birdie->setLinearVelocity(b2Vec2(-mx_a*5,my_a*2));
                break;
            case 11:
                black->getself().SetGravityScale(0.98f);
                black->setLinearVelocity(b2Vec2(-mx_a*5,my_a*2));
                break;
            case 16:
                white->getself().SetGravityScale(0.98f);
                white->setLinearVelocity(b2Vec2(-mx_a*5,my_a*2));
                break;
            case 21:
                blue->getself().SetGravityScale(0.98f);
                blue->setLinearVelocity(b2Vec2(-mx_a*5,my_a*2));
                break;
        }
        BIRD_INDEX_move++;
        /* TODO : add your code here */
        //std::cout << "Release !" << std::endl ;
    }
    if(event->type() == QEvent::KeyPress){
        switch(BIRD_INDEX_move){
            case 1:
                //birdie->test(rx_o+mx_a,rx_o+my_a);
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
        }
        /*
        QKeyEvent* key = static_cast<QKeyEvent*>(event);
        if(key->key() == Qt::Key_P)
            birdie->setLinearVelocity(b2Vec2(2.5f,2.5f));
        */
    }
    return false;
}

void MainWindow::closeEvent(QCloseEvent *)
{
    // Close event
    emit quitGame();
}

void MainWindow::tick()
{

    world->Step(1.0/60.0,6,2);
    std::cout<<"index:"<<BIRD_INDEX<<std::endl;
    std::cout<<"index mvoe:"<<BIRD_INDEX_move<<std::endl;
    scene->update();
}

void MainWindow::QUITSLOT()
{
    // For debug
    std::cout << "Quit Game Signal receive !" << std::endl ;
}
