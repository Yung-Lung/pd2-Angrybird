#include "mainwindow.h"
#include <QApplication>

QString *BIRD = new QString("bird");
QString *LAND = new QString("land");
QString *PIG = new QString("pig");
QString *BAR = new QString("bar");

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
