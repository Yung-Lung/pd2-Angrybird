#include "mycallback.h"

MyCallBack::MyCallBack()
{

}
