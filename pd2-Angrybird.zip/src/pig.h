#include <mainwindow.h>
#include <gameitem.h>
#ifndef PIG_H
#define PIG_H


class Pig : public GameItem
{
public:
    Pig(float x, float y, float radius, QTimer *timer, QPixmap pixmap, b2World *world, QGraphicsScene *scene);
    void setLinearVelocity(b2Vec2 velocity);
    void test(double a, double b);
};

#endif // PIG_H
